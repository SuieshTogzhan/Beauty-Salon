from django.db import models


class Masters(models.Model):
    name = models.CharField(max_length=100)
    img = models.ImageField(upload_to='pics')
    type = models.CharField(max_length=100)
    experience = models.IntegerField()






