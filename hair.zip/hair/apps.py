from django.apps import AppConfig


class HairConfig(AppConfig):
    name = 'hair'
