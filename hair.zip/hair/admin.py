from django.contrib import admin
from .models import Hair

# Register your models here.
admin.site.register(Hair)