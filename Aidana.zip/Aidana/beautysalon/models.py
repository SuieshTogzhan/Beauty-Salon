from django.db import models


class Service(models.Model):
    name = models.CharField(max_length=100)
    img = models.ImageField(upload_to='pics')
    desc = models.TextField()
    price = models.IntegerField()
    offer = models.BooleanField(default=False)


class Comment(models.Model):
    author = models.CharField(max_length=100, null=True)
    text = models.TextField()
