from django.shortcuts import render
from .models import Hair


def index(request):
    return render(request, "index.html")
