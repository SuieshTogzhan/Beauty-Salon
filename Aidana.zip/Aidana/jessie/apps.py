from django.apps import AppConfig


class JessieConfig(AppConfig):
    name = 'jessie'
