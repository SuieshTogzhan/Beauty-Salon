from django.shortcuts import render, redirect
from . import forms
from .models import Zapis
from django.contrib import messages


def jessie(request):
    form = forms.Zapis1(request.POST)
    posts = Zapis.objects.all()
    if request.method == "POST":
        date = request.POST['date']
        time = request.POST['time']
        service = request.POST['service']
        if date and time and service is not None:
            if Zapis.objects.filter(date=date).exists():
                if Zapis.objects.filter(time=time).exists():
                    messages.info(request, 'This time is busy')
                    return redirect('jessie')
                else:
                    z = Zapis.objects.create(date=date, time=time, service=service)
                    z.save()
                    return redirect('jessie')
            else:
                z = Zapis.objects.create(date=date, time=time, service=service)
                z.save()
                return redirect('jessie')
        else:
            messages.info(request, "Please, fill all fields")
            return redirect('jessie')
    return render(request, 'jessie.html', {'form': form, 'post': posts})
