from django.db import models


class Search(models.Model):
    service_choice = (
        ('Ombre coloring', 'Ombre coloring'),
        ('Balayage coloring', 'Balayage coloring'),
        ('Short hairstyle', 'Short hairstyle'),
        ('Cascade hairstyle', 'Cascade hairstyle'),
        ('Curly hairstyle', 'Curly hairstyle'),
        ('Daily makeup', 'Daily makeup'),
        ('Easy makeup', 'Easy makeup'), ('Bright makeup', 'Bright makeup'),
        ('Night makeup', 'Night makeup'), ('Hollywood makeup', 'Hollywood makeup'),
        ('Manicure', 'Manicure'), ('Pedicure', 'Pedicure'),
        ('Gel coating', 'Gel coating'), ('Nail extension', 'Nail extension'),
        ('Strengthening', 'Strengthening'),

    )
    price_choice = (
        ('2500', '2500'), ('3000', '3000'), ('3500', '3500'),
        ('4000', '4000'), ('4500', '4500'), ('5000', '5000'),
        ('5500', '5500'), ('6000', '6000'), ('6500', '6500'),
        ('15000', '15000'), ('20000', '20000'), ('25000', '25000'),

    )
    price = models.CharField(max_length=10, blank=True, choices=price_choice)
    service = models.CharField(max_length=30, blank=True, choices=service_choice)
    master = models.CharField(max_length=100, blank=True)
    img = models.ImageField(upload_to='pics')
