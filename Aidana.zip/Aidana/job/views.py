from django.shortcuts import render, redirect
from .models import job
from . import forms
from django.contrib import messages


def index(request):
    form = forms.Job(request.POST)
    if request.method == 'POST':
        name = request.POST['name']
        surname = request.POST['surname']
        age = request.POST['age']
        experience = request.POST['experience']
        language = request.POST['language']
        phone = request.POST['phone']

        if name and surname and age and experience and language and phone is not None:
            user = job.objects.create(name=name, surname=surname, age=age,
                                      experience=experience, language=language, phone=phone)
            user.save()
            messages.info(request, "Thank you, we will call you if your CV fits our requirements ")

        else:
            messages.info(request, "Please, fill all fields")
            return redirect('job')
        return redirect('job')
    else:
        return render(request, 'job.html', {'form': form})

def test(request):
    return render(request, 'test.html')







