from django.urls import path, include
from . import views

urlpatterns = [
    path('', views.index, name='job'),
    path('test/', views.test, name='test'),
]
