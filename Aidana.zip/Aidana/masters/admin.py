from django.contrib import admin
from .models import Masters

# Register your models here.
admin.site.register(Masters)