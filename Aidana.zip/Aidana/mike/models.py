from django.db import models


class Zapis(models.Model):
    service_choice = (
        ('Ombre', 'Ombre'),
        ('Balayage', 'Balayage'),
        ('Short', 'Short'),
        ('Cascade', 'Cascade'),
        ('Curly', 'Curly'),
    )
    time_choice = (
        ('10:00', '10:00'),
        ('11:30', '11:30'),
        ('13:00', '13:00'),
        ('14:30', '14:30'),
        ('16:00', '16:00'),
        ('17:30', '17:30'),
        ('19:00', '19:00'),
        ('20:30', '20:30'),
    )
    date = models.DateField("Purchase Date (year-month-day)", auto_now_add=False,
                            auto_now=False, blank=True)
    time = models.CharField(max_length=10, blank=True, choices=time_choice)
    service = models.CharField(max_length=30, blank=True, choices=service_choice)

