from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static


urlpatterns = [
    path('', include('beautysalon.urls')),
    path('admin/', admin.site.urls),
    path('accounts/', include('accounts.urls')),
    path('about/', include('about.urls')),
    path('job/', include('job.urls')),
    path('accounts/about', include('about.urls')),
    path('jessie/', include('jessie.urls')),
    path('lola/', include('lola.urls')),
    path('mike/', include('mike.urls')),
    path('mike/accounts/', include('accounts.urls')),
    path('lola/accounts/', include('accounts.urls')),
    path('job/accounts/', include('accounts.urls')),
    path('jessie/accounts/', include('accounts.urls')),



]

urlpatterns = urlpatterns + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

