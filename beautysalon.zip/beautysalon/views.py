from django.shortcuts import render, redirect
from .models import Service, Comment
from hair.models import Hair
from masters.models import Masters
from accounts.views import User

def index(request):
    serv = Service.objects.all()
    hair = Hair.objects.all()
    masters = Masters.objects.all()

    comments = Comment.objects.all()
    if request.method == 'POST':
        text = request.POST['text']
        comment = Comment(author=request.user, text=text)
        comment.save()
        return redirect('/')
    return render(request, "index.html", {'serv': serv, 'hair': hair, 'masters': masters, 'comments': comments})




