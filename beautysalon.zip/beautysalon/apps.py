from django.apps import AppConfig


class BeautysalonConfig(AppConfig):
    name = 'beautysalon'
