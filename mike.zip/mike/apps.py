from django.apps import AppConfig


class MikeConfig(AppConfig):
    name = 'mike'
