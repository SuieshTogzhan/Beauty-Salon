from django import forms
from . import models


class Zapis1(forms.ModelForm):
    class Meta:
        model = models.Zapis
        fields = ['time', 'service']
