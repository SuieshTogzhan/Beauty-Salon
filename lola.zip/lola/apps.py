from django.apps import AppConfig


class LolaConfig(AppConfig):
    name = 'lola'
