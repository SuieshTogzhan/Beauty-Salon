from django.db import models


class job(models.Model):
    name = models.CharField(max_length=100, blank=True)
    surname = models.CharField(max_length=100, blank=True)
    age = models.CharField(max_length=100, blank=True)
    experience = models.CharField(max_length=300, blank=True)
    language = models.CharField(max_length=100, blank=True)
    phone = models.CharField(max_length=100, blank=True, )



