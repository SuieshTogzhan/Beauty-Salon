from django.shortcuts import render, redirect
from .models import job
from . import forms
from django.contrib import messages


def index(request):
    form = forms.Job(request.POST)
    if request.method == 'POST':
        name = request.POST['name']
        surname = request.POST['surname']
        age = request.POST['age']
        experience = request.POST['experience']
        language = request.POST['language']
        phone = request.POST['phone']

        if name and surname and age and experience and language and phone is not None:
            user = job.objects.create(name=name, surname=surname, age=age,
                                      experience=experience, language=language, phone=phone)
            user.save()
            messages.info(request, "Thank you, we will call you if your CV fits our requirements ")

        else:
            messages.info(request, "Please, fill all fields")
            return redirect('job')
        return redirect('job')
    else:
        return render(request, 'job.html', {'form': form})


def test(request):
    return render(request, 'test.html')


def ans(request):
    if request.method == 'POST':
        i1 = request.POST.get('i1', False)
        i2 = request.POST.get('i2', False)
        i3 = request.POST.get('i3', False)
        a1 = request.POST.get('a1', False)
        a2 = request.POST.get('a2', False)
        a3 = request.POST.get('a3', False)
        b1 = request.POST.get('b1', False)
        b2 = request.POST.get('b2', False)
        b3 = request.POST.get('b3', False)
        c1 = request.POST.get('c1', False)
        c2 = request.POST.get('c2', False)
        c3 = request.POST.get('c3', False)
        d1 = request.POST.get('d1', False)
        d2 = request.POST.get('d2', False)
        d3 = request.POST.get('d3', False)

        count = 0
        if i3:
            count += 1
        if a1:
            count += 1
        if b2:
            count += 1
        if c3:
            count += 1
        if d1:
            count += 1

        if count > 3:
            messages.info(request, "Congrats!!! We will check your CV!")
            return redirect('test')
        else:
            messages.info(request, "Sorry. Hope you can find another job :D")
            return redirect('test')

    return render(request, 'test.html')








