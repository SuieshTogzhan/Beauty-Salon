from django import forms
from . import models


class Job(forms.ModelForm):
    class Meta:
        model = models.job
        fields = ['name', 'surname', 'age', 'experience', 'language', 'phone']
