from django.shortcuts import render,redirect
from .models import Search
from . import forms
from django.contrib import messages
from django.utils.datastructures import MultiValueDictKeyError


def about(request):
    print(request)
    # sear = Search.objects.all()
    form = forms.Search1(request.GET)
    try:
        if request.method == 'GET':
            price = request.GET['price']
            service = request.GET['service']
            if Search.objects.filter(service=service).exists():
                if Search.objects.filter(price=price).exists():
                    sear1 = Search.objects.filter(service=service)
                    return render(request, 'about.html', {'sear': sear1, 'form': form})
                else:
                    messages.info(request, 'There is no service matching ')
                    return render(request, 'about.html', {'form': form})

    except MultiValueDictKeyError:
        return render(request, 'about.html', {'form': form})
    return render(request, 'about.html', {'form': form})




